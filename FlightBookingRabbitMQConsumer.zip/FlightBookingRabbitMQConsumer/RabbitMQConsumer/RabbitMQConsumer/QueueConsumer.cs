﻿using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace RabbitMQConsumer
{
    public static class QueueConsumer
    {
        public static void consume(IModel channel)
        {
            channel.QueueDeclare("FlightBookingAppTest", durable: true, exclusive: false, autoDelete: false, arguments: null);

            var consumer = new RabbitMQ.Client.Events.EventingBasicConsumer(channel);
            consumer.Received += (sender, e) =>
            {
                var body = e.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);
                Console.WriteLine(message);
            };

            channel.BasicConsume("FlightBookingAppTest", true, consumer);
            Console.WriteLine("Consumer has started and below message received:- ");
            Console.ReadLine();
        }
    }
}
