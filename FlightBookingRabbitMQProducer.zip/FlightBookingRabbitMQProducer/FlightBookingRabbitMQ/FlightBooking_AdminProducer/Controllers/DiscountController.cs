﻿using FlightBooking_AdminProducer.Models;
using FlightBooking_AdminProducer.Repository.Abstract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Controllers
{

    [ApiController]
    [Route("api/ManageDiscount")]
    public class DiscountController : Controller
    {
        private readonly IRepositoryCollection DiscountServiceCollection;
        public IConfiguration Configuration1 { get; }

        public DiscountController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            DiscountServiceCollection = _IServiceCollection;
            Configuration1 = configuration;
        }

        [Route("AddDiscount")]
        [HttpPost]
        public async Task<IActionResult> AddFlight([FromBody] DiscountModel discountModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var objDiscount = await DiscountServiceCollection.ManageDiscount.AddDiscount(discountModel);
                var channel = Getconnection();
                var message = discountModel;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);
                return Ok(objDiscount);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        
        [HttpGet("DeleteDiscount/{DiscountId}")]
        public async Task<IActionResult> DeleteDiscount([FromRoute] int DiscountId)
        {
           
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var obj = await DiscountServiceCollection.ManageDiscount.DeleteDiscount(DiscountId);

                var channel = Getconnection();
                var message = obj;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                return Ok(obj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetDiscount")]
        [HttpGet]
        public async Task<IActionResult> GetAllDiscount()
        {
            try
            {
                var objListDiscount = await DiscountServiceCollection.ManageDiscount.GetDiscount();
                var channel = Getconnection();
                var message = objListDiscount;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);
                return Ok(objListDiscount);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public IModel Getconnection()
        {
            var factory = new ConnectionFactory
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")
            };

            var connection = factory.CreateConnection();
            return connection.CreateModel();

        }
    }
}
