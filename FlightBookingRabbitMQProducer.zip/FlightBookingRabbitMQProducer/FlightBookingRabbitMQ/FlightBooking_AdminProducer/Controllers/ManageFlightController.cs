﻿using FlightBooking_AdminProducer.Models;
using FlightBooking_AdminProducer.Repository.Abstract;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Controllers
{

    [EnableCors("CorsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class ManageFlightController : ControllerBase
    {
        private readonly IRepositoryCollection manageFlightCollection;
        public IConfiguration iConfiguration { get; }

        public ManageFlightController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            manageFlightCollection = _IServiceCollection;
            iConfiguration = configuration;
        }

       
        [Route("AddFlight")]
        [HttpPost]
        public async Task<IActionResult> AddFlight([FromBody] AirlineModel objAirline)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var objAddFlightReturnType = await manageFlightCollection.ManageFlightRepository.AddFlight(objAirline);
                var channel = Getconnection();
                var message = objAirline;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);
                return Ok(objAddFlightReturnType);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("BlockFlight/{flightId}")]
        public async Task<IActionResult> BlockFlight([FromRoute]int flightId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {

                var objBlockFlightReturnType =await manageFlightCollection.ManageFlightRepository.BlockFlight(flightId);

                var channel = Getconnection();
                var message = objBlockFlightReturnType;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                return Ok(objBlockFlightReturnType);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[EnableCors("AllowOrigin")]
        [Route("GetFlight")]
        [HttpGet]
        public async Task<IActionResult> GetAllFlight()
        {
            try
            {
                var objGetAllFlight = await manageFlightCollection.ManageFlightRepository.GetAirPort();

                var channel = Getconnection();
                var message = objGetAllFlight;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[Route("IsFlightExist")]
        //[HttpPost]
        //public async Task<IActionResult> IsFlightExist(string flightnumber, string flightName)
        //{
        //    try
        //    {
        //        var objIsFlightExist = await manageFlightCollection.ManageFlightRepository.IsFlightExist(flightnumber,flightName);
        //        return Ok(objIsFlightExist);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        [Route("GetAllMeal")]
        [HttpGet]
        public async Task<IActionResult> GetAllMeal()
        {
            try
            {
                var objGetAllFlight = await manageFlightCollection.ManageFlightRepository.GetMeal();

                var channel = Getconnection();
                var message = objGetAllFlight;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [Route("AddFlightSchedule")]
        [HttpPost]
        public async Task<ActionResult<ResponseMessageModel>> FlightSchedule([FromBody] FlightScheduledModel objFlightSchedule)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
            if (ModelState.IsValid)
            {
                try
                {
                    _responsemessagemodel = await manageFlightCollection.ManageFlightRepository.AddFlightScheduled(objFlightSchedule);
                    if (_responsemessagemodel != null)
                    {
                        var channel = Getconnection();
                        var message = objFlightSchedule;
                        var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                        QueueProducer.publish(channel, body);
                        return Ok(_responsemessagemodel);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            else
            {
                return BadRequest();
            }
               
        }

        [Route("GetActiveAirLineBeforeScheduled")]
        [HttpGet]
        public async Task<IActionResult> GetAirLineBeforeScheduled()
        {
            try
            {
                var objGetAllFlight = await manageFlightCollection.ManageFlightRepository.GetActiveAirLineBeforeScheduled();

                var channel = Getconnection();
                var message = objGetAllFlight;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetScheduleAirlineDetails")]
        [HttpGet]
        public async Task<IActionResult> GetScheduleAirlineDetails()
        {
            try
            {
                var objGetAllFlight = await manageFlightCollection.ManageFlightRepository.GetAirlineScheduledDetails();

                var channel = Getconnection();
                var message = objGetAllFlight;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                if (objGetAllFlight == null)
                {
                    return NotFound(objGetAllFlight);
                }
                else
                {
                    return Ok(objGetAllFlight);
                }
                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public IModel Getconnection()
        {
            var factory = new ConnectionFactory
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")
            };

            var connection = factory.CreateConnection();
            return connection.CreateModel();

        }
    }
}
