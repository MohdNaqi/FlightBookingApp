﻿using System;
using System.Collections.Generic;

namespace FlightBooking_AdminProducer.Entity
{
    public partial class Discount
    {
        public int DiscountId { get; set; }
        public string CouponCode { get; set; }
        public int? DiscountValue { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
