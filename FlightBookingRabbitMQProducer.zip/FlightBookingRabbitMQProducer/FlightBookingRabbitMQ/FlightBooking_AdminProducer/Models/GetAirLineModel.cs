﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Models
{
    public class GetAirLineModel
    {
        public int AirLineId { get; set; }
        public string AirLineNumber { get; set; }
        public string AirLineName { get; set; }
        public bool IsActive { get; set; }
    }
}
