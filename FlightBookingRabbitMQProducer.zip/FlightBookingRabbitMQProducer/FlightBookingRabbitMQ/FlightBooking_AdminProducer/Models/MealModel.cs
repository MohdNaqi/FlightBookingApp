﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Models
{
    public class MealModel
    {
        public int MealId { get; set; }
        public string MealName { get; set; }
    }
}
