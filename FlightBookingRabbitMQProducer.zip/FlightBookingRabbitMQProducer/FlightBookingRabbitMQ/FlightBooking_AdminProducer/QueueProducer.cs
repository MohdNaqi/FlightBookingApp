﻿using FlightBooking_AdminProducer.Models;

using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer
{
    public static class QueueProducer
    {
        public static void publish(IModel channel, byte[] body)
        {
            channel.QueueDeclare("FlightBookingAppTest", durable: true, exclusive: false, autoDelete: false, arguments: null);
            channel.BasicPublish("", "FlightBookingAppTest", null, body);
        }
    }
}
