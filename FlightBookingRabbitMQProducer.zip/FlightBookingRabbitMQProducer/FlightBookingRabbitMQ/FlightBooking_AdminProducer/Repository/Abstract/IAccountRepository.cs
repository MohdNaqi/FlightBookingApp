﻿using FlightBooking_AdminProducer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Repository.Abstract
{
    public interface IAccountRepository : IDisposable
    {
        Task<LoginResponseMessageModel> UserLogin(LoginModel objLoginModel);

    }
}
