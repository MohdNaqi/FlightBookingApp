﻿using FlightBooking_AdminProducer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Repository.Abstract
{
    public interface IDiscountRepository : IDisposable
    {
        Task<int> AddDiscount(DiscountModel discountModel);
        Task<List<GetDiscountModel>> GetDiscount();
        Task<int> DeleteDiscount(int DiscountId);
    }
}
