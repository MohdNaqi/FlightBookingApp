﻿using FlightBooking_AdminProducer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Repository.Abstract
{
    public interface IManageFlightRepository
    {
        Task<int> AddFlight(AirlineModel objAirport);
        Task<int> BlockFlight(int flightId);
        Task<List<GetAirLineModel>> GetAirPort();
        Task<bool> IsFlightExist(string flightNumber, string flightName);
        Task<List<MealModel>> GetMeal();
        Task<ResponseMessageModel> AddFlightScheduled(FlightScheduledModel objFlightScheduledModel);
        Task<List<GetAirLineModel>> GetActiveAirLineBeforeScheduled();
        Task<List<AirlineScheduleModel>> GetAirlineScheduledDetails();
    }
} 