﻿using FlightBooking_AdminProducer.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminProducer.Repository.Abstract
{
    public interface IRepositories : IDisposable
    {
        FlightBookingContext flightBookingContext { get; }
    }
}
