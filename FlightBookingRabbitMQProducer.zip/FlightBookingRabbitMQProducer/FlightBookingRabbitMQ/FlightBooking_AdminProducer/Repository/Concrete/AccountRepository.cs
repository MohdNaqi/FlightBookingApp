﻿
using FlightBooking_AdminProducer.Entity;
using FlightBooking_AdminProducer.Models;
using FlightBooking_AdminProducer.Repository.Abstract;
using FlightBooking_AdminProducer.Utility;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;

namespace FlightBooking_AdminProducer.Repository.Concrete
{
    public class AccountRepository : Repositories, IAccountRepository
    {

        public async Task<LoginResponseMessageModel> UserLogin(LoginModel objLoginModel)
        {
            LoginResponseMessageModel _responseMessageModel = new LoginResponseMessageModel();
            try
            {
                var passwordHash = objLoginModel.Password.RemoveWhiteSpace().GetStringSha256Hash();
                LoginDetailsModel objLogin =new LoginDetailsModel();
                flightBookingContext.Database.OpenConnection();
                DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
                cmd.CommandText = "ValidateUser";
                cmd.CommandType =  CommandType.StoredProcedure;
                SqlParameter param = new SqlParameter("@UserName", objLoginModel.UserName);
                SqlParameter param1 = new SqlParameter("@Password", passwordHash);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(param1);
                var reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        objLogin.Email =Convert.ToString(reader["Email"]);
                        objLogin.UserName = Convert.ToString(reader["UserName"]);
                        objLogin.FirstName = Convert.ToString(reader["FirstName"]);
                        objLogin.LastName = Convert.ToString(reader["LastName"]);
                        objLogin.UserType = Convert.ToInt32(reader["UserType"]);

                    }
                    if(objLogin != null)
                    {
                         if(objLogin.UserType == 1)
                        {
                            _responseMessageModel.id = Convert.ToInt64(objLogin.UserType);
                            _responseMessageModel.responsemessage = "Admin Login Success";
                        }else if (objLogin.UserType == 2)
                        {
                            _responseMessageModel.id = Convert.ToInt64(objLogin.UserType);
                            _responseMessageModel.responsemessage = "User Login Success";
                        }
                        else if (objLogin.UserType == 0)
                        {
                            _responseMessageModel.id = Convert.ToInt64(0);
                            _responseMessageModel.responsemessage = "Invalid User.";
                        }
                    }
                    flightBookingContext.Database.CloseConnection();

                }
                else
                {
                    _responseMessageModel.id = Convert.ToInt64(0);
                    _responseMessageModel.responsemessage = "Invalid User.";
                }
                return await Task.FromResult(_responseMessageModel); 
            }
            catch (Exception ex)
            {
                throw;
                
            }
        }


    }
}
