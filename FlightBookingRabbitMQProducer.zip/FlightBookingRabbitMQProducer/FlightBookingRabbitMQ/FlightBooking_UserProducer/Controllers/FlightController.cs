﻿    using FlightBooking_UserProducer.Models;
using FlightBooking_UserProducer.Repository.Abstract;
using FlightBooking_UserProducer.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightBooking_UserProducer.Controllers
{
    //[Microsoft.AspNetCore.Cors.EnableCors("CorsPolicy")]
    [ApiController]
    [Route("api/[controller]")]
    public class FlightController : Controller
    {
        private readonly IRepositoryCollection bookingServiceCollection;
        public IConfiguration Configuration1 { get; }

        public FlightController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            bookingServiceCollection = _IServiceCollection;
            Configuration1 = configuration;
        }

        [Route("Search")]
        [HttpPost]
        public async Task<IActionResult> SearchFlight([FromBody] SearchFlightModel objSearchFlight)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var objSearchFlightReturntype = await bookingServiceCollection.BookingRepository.SearchFlight(objSearchFlight);

                var channel = Getconnection();
                var message = objSearchFlight;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                return Ok(objSearchFlightReturntype);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("Booking")]
        [HttpPost]
        public async Task<ActionResult<ResponseMessageModel>> FlightBooking([FromBody] FlightBookingModel flightBooking)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
            if (ModelState.IsValid)
            {
                try
                {
                    _responsemessagemodel = await bookingServiceCollection.BookingRepository.FlightBooking(flightBooking);
                    if (_responsemessagemodel != null)
                    {
                        var channel = Getconnection();
                        var message = flightBooking;
                        var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                        QueueProducer.publish(channel, body);
                        return Ok(_responsemessagemodel);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            else
            {
                return BadRequest();
            }
        }

      
        [HttpGet("BookingFlightCancel/{bookingId}")]
        public async Task<ActionResult<ResponseMessageModel>> BookingFlightCancel([FromRoute] int bookingId)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
                {
                    _responsemessagemodel = await bookingServiceCollection.BookingRepository.flightBookingCancel(bookingId);
                    if (_responsemessagemodel != null)
                    {
                    var channel = Getconnection();
                    var message = _responsemessagemodel;
                    var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                    QueueProducer.publish(channel, body);
                    return Ok(_responsemessagemodel);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }

     
        [HttpGet("FlightBookingDetails/{PNR_No}")]
        public async Task<ActionResult<List<BookingDetailsViewModel>>> GetFlightBookingDetails([FromRoute] long PNR_No)
        {
            List<BookingDetailsViewModel> bookingDetailsView = new List<BookingDetailsViewModel>();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                bookingDetailsView = await bookingServiceCollection.BookingRepository.BookTicketDetails(PNR_No);
                if (bookingDetailsView != null)
                {
                    var channel = Getconnection();
                    var message = bookingDetailsView;
                    var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                    QueueProducer.publish(channel, body);

                    return Ok(bookingDetailsView);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


  
        [HttpGet("GetFlightBookingHistory/{emailid}")]
        public async Task<ActionResult<List<BookingDetailsViewModel>>> GetFlightBookingHistory([FromRoute] string emailid)
        {
            List<BookingDetailsViewModel> bookingDetailsView = new List<BookingDetailsViewModel>();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                bookingDetailsView = await bookingServiceCollection.BookingRepository.BookingHistoryDetailsByEmailId(emailid);
                if (bookingDetailsView != null)
                {
                    var channel = Getconnection();
                    var message = bookingDetailsView;
                    var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                    QueueProducer.publish(channel, body);
                    return Ok(bookingDetailsView);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetActiveFlight")]
        [HttpGet]
        public async Task<IActionResult> GetAllActiveFlight()
        {
            try
            {
                var objGetAllFlight = await bookingServiceCollection.BookingRepository.GetActiveAirLine();
                var channel = Getconnection();
                var message = objGetAllFlight;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);
                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetActiveAirlineSchedule")]
        [HttpGet]
        public async Task<IActionResult> GetActiveAirlineSchedule()
        {
            try
            {
                var objGetAllFlight = await bookingServiceCollection.BookingRepository.GetActiveAirlineSchedule();

                var channel = Getconnection();
                var message = objGetAllFlight;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);
                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetBookTicket")]
        [HttpGet]
        public async Task<IActionResult> GetBookTicket()
        {
            try
            {
                var lstbookticket = await bookingServiceCollection.BookingRepository.GetBookTicket();

                var channel = Getconnection();
                var message = lstbookticket;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);

                return Ok(lstbookticket);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }




        [HttpGet("getDiscountConpen/{flightid}")]
        public async Task<ActionResult<DiscountModel>> GetFlightBookingDetails(int flightid)
        {
            DiscountModel obj = new DiscountModel();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                obj = await bookingServiceCollection.BookingRepository.GetPriceandDiscountCoupen(flightid);
                if (obj != null)
                {
                    var channel = Getconnection();
                    var message = obj;
                    var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                    QueueProducer.publish(channel, body);
                    return Ok(obj);
                }
                else
                {
                    return NotFound(obj);
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public IModel Getconnection()
        {
            var factory = new ConnectionFactory
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")
            };

            var connection = factory.CreateConnection();
            return connection.CreateModel();

        }

    }
}
