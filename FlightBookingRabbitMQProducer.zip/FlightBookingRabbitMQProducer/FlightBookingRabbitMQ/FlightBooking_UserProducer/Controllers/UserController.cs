﻿using FlightBooking_UserProducer;
using FlightBooking_UserProducer.Models;
using FlightBooking_UserProducer.Repository.Abstract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace FlightBooking_AdminApiService.Controllers
{
    [ApiController]
    [Route("api/User")]
    public class UserController : Controller
    {
        private readonly IRepositoryCollection UserServiceCollection;
        public IConfiguration Configuration1 { get; }

        public UserController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            UserServiceCollection = _IServiceCollection;
            Configuration1 = configuration;
        }

        [Route("login")]
        [HttpPost]
        public async Task<IActionResult> AdminLogin([FromBody] LoginModel objLogin)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var ObjLoginReturnType = await UserServiceCollection.AccountRepository.UserLogin(objLogin);
                var channel = Getconnection();
                var message = objLogin;
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                QueueProducer.publish(channel, body);
                return Ok(ObjLoginReturnType);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("AddUserRegistration")]
        [HttpPost]
        public async Task<ActionResult<ResponseMessageModel>> AddUserRegistration([FromBody] UserRegistrationModel obj)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                _responsemessagemodel = await UserServiceCollection.AccountRepository.AddUserRegistration(obj);
                if (_responsemessagemodel != null)
                {
                    var channel = Getconnection();
                    var message = obj;
                    var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
                    QueueProducer.publish(channel, body);
                    return Ok(_responsemessagemodel);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public IModel Getconnection()
        {
            var factory = new ConnectionFactory
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")
            };

            var connection = factory.CreateConnection();
            return connection.CreateModel();

        }
    }
}
