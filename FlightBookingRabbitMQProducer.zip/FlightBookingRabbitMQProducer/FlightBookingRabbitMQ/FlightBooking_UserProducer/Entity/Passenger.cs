﻿using System;
using System.Collections.Generic;

namespace FlightBooking_UserProducer.Entity
{
    public partial class Passenger
    {
        public int PassengerId { get; set; }
        public int? PassengerBookingId { get; set; }
        public string PassengerType { get; set; }
        public string PassengerFirstName { get; set; }
        public string PassengerLastName { get; set; }
        public string PassengerEmail { get; set; }
        public string PassengerGender { get; set; }
        public int? MealId { get; set; }
        public int? Createdby { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
