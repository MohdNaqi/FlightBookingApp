﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserProducer.Models
{
    public class MealModel
    {
        public int MealId { get; set; }
    }
}
