﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserProducer.Models
{
    public class ResponseMessageModel
    {
        public long id { get; set; }
        public string responsemessage { get; set; }
    }
}
