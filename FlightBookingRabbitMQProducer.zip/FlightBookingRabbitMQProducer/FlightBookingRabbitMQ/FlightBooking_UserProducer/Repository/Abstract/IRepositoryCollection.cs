﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserProducer.Repository.Abstract
{
    public interface IRepositoryCollection : IDisposable
    {
        IAccountRepository AccountRepository { get; }

        IBookingRepository BookingRepository { get; }
    }
}
