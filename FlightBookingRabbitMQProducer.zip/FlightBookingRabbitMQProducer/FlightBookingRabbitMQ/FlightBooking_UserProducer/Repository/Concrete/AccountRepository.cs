﻿
using FlightBooking_UserProducer.Utility;
using FlightBooking_UserProducer.Entity;
using FlightBooking_UserProducer.Models;
using FlightBooking_UserProducer.Repository.Abstract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;

namespace FlightBooking_UserProducer.Repository.Concrete
{
    public class AccountRepository : Repositories, IAccountRepository
    {

        [HttpPost("[login]")]
        public async Task<LoginDetailsModel> UserLogin(LoginModel objLoginModel)
        {
            try
            {
                var passwordHash = objLoginModel.Password.RemoveWhiteSpace().GetStringSha256Hash();
                LoginDetailsModel objLogin = new LoginDetailsModel();
                flightBookingContext.Database.OpenConnection();
                DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
                cmd.CommandText = "ValidateUser";
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter param = new SqlParameter("@UserName", objLoginModel.UserName);
                SqlParameter param1 = new SqlParameter("@Password", objLoginModel.Password);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(param1);
                var reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        objLogin.Email = Convert.ToString(reader["Email"]);
                        objLogin.UserName = Convert.ToString(reader["UserName"]);
                        objLogin.FirstName = Convert.ToString(reader["FirstName"]);
                        objLogin.LastName = Convert.ToString(reader["LastName"]);
                        objLogin.UserType = Convert.ToInt32(reader["UserType"]);

                    }
                    flightBookingContext.Database.CloseConnection();

                }
                else
                {
                    return null;
                }
                return await Task.FromResult(objLogin);
            }
            catch (Exception ex)
            {
                throw;

            }
        }

        public async Task<ResponseMessageModel> AddUserRegistration(UserRegistrationModel registrationModel)
        {
            int userAccountId = 0;
            ResponseMessageModel _responseMessageModel = new ResponseMessageModel();
            var isUserExists = flightBookingContext.UserAccount.Where(x => x.UserName == registrationModel.UserName).FirstOrDefault();
            if(isUserExists == null)
            {
                var passwordHash = registrationModel.password.RemoveWhiteSpace().GetStringSha256Hash();
                var objAddUserRegistration = new FlightBooking_UserProducer.Entity.UserAccount()
                {

                    UserName = registrationModel.UserName,
                    FirstName = registrationModel.FirstName,
                    LastName = registrationModel.LastName,
                    Email = registrationModel.Email,
                    PhoneNumber = registrationModel.PhoneNumber,
                    Password = passwordHash,
                    CreatedBy = "User",
                    CreatedOn = DateTime.UtcNow,
                    UserType = 2,
                    IsActive = true

                };
                flightBookingContext.UserAccount.Add(objAddUserRegistration);
                flightBookingContext.SaveChanges();
                userAccountId = objAddUserRegistration.Id;
                if (userAccountId != 0)
                {
                    var objUserAddress = new FlightBooking_UserProducer.Entity.Address()
                    {

                        UserAccountId = userAccountId,
                        Address11 = registrationModel.Address11,
                        Address1 = registrationModel.Address1,
                        CityName = registrationModel.CityName,
                        StateName = registrationModel.StateName,
                        CountryName = registrationModel.CountryName,
                        ZipCode = registrationModel.ZipCode,
                        CreatedBy = userAccountId,
                        CreatedDate = DateTime.UtcNow,
                    };
                    flightBookingContext.Address.Add(objUserAddress);
                    flightBookingContext.SaveChanges();
                }
                //return await Task.FromResult(userAccountId);
                _responseMessageModel.id = userAccountId;
                _responseMessageModel.responsemessage = "Record inserted sucessfully";
            }
            else
            {
                _responseMessageModel.id = userAccountId;
                _responseMessageModel.responsemessage = "UserName already registered";
            }
            return await Task.FromResult(_responseMessageModel);
        }


    }
}
