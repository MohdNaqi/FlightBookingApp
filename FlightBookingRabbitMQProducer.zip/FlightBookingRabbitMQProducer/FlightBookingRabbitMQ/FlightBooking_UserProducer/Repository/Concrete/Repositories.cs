﻿using FlightBooking_UserProducer.Entity;

using FlightBooking_UserProducer.Repository.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserProducer.Repository.Concrete
{
    public class Repositories : IRepositories
    {
        public Repositories()
        {
            this.flightBookingContext = new FlightBookingContext();
        }
        public FlightBookingContext flightBookingContext { get; private set; }
        public void Dispose()
        {
            GC.SuppressFinalize("");
        }
    }
}
