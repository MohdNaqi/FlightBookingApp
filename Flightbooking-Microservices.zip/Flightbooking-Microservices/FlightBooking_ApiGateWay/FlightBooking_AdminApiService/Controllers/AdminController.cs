﻿
using FlightBooking_AdminApiService.JwtClass;
using FlightBooking_AdminApiService.Models;
using FlightBooking_AdminApiService.Repository.Abstract;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace FlightBooking_AdminApiService.Controllers
{
    [EnableCors("CorsPolicy")]
    //[Route("api/[controller]")]
    [ApiController]
    [Route("api/account")]
    public class AdminController : Controller
    {
        private readonly IRepositoryCollection AdminServiceCollection;
        private readonly JwtManager jwtManager;
        public IConfiguration Configuration1 { get; }

        public AdminController(IRepositoryCollection _IServiceCollection, IConfiguration configuration, IOptions<JwtIssuerOptions> jwtOptions)
        {
            AdminServiceCollection = _IServiceCollection;
            jwtManager = new JwtManager(jwtOptions);
            Configuration1 = configuration;
        }

        [Route("login")]
        [HttpPost]
        public async Task<ActionResult<LoginResponseMessageModel>> AdminLogin([FromBody] LoginModel objLogin)
        {
            string Token = "";
            LoginResponseMessageModel _responsemessagemodel = new LoginResponseMessageModel();
            if (ModelState.IsValid)
            {
                try
                {
                    Token = await jwtManager.GenerateToken(objLogin.UserName);
                    _responsemessagemodel = await AdminServiceCollection.AccountRepository.UserLogin(objLogin);
                    if (_responsemessagemodel != null)
                    {
                        _responsemessagemodel.AccessToken = Token;
                        return Ok(_responsemessagemodel);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            else
            {
                return BadRequest();
            }


        }

    }
}
