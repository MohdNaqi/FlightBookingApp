﻿using FlightBooking_AdminApiService.Models;
using FlightBooking_AdminApiService.Repository.Abstract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Controllers
{

    [ApiController]
    [Route("api/ManageDiscount")]
    public class DiscountController : Controller
    {
        private readonly IRepositoryCollection DiscountServiceCollection;
        public IConfiguration Configuration1 { get; }

        public DiscountController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            DiscountServiceCollection = _IServiceCollection;
            Configuration1 = configuration;
        }

        [Route("AddDiscount")]
        [HttpPost]
        public async Task<IActionResult> AddFlight([FromBody] DiscountModel discountModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var objDiscount = await DiscountServiceCollection.ManageDiscount.AddDiscount(discountModel);
                return Ok(objDiscount);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        
        [HttpGet("DeleteDiscount/{DiscountId}")]
        public async Task<IActionResult> DeleteDiscount([FromRoute] int DiscountId)
        {
           
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var obj = await DiscountServiceCollection.ManageDiscount.DeleteDiscount(DiscountId);

               
                    return Ok(obj);
               
               
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetDiscount")]
        [HttpGet]
        public async Task<IActionResult> GetAllDiscount()
        {
            try
            {
                var objListDiscount = await DiscountServiceCollection.ManageDiscount.GetDiscount();
                if(objListDiscount == null)
                {
                    return NotFound(objListDiscount);
                }
                else{
                    return Ok(objListDiscount);
                }
                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
