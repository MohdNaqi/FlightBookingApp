﻿using System;
using System.Collections.Generic;

namespace FlightBooking_AdminApiService.Entity
{
    public partial class ScheduledDays
    {
        public int Id { get; set; }
        public string ScheduledDay { get; set; }
    }
}
