﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Models
{
    public class AirLineModel1
    {
        public int Id { get; set; }
        public string AirLineNumber { get; set; }
        public string AirlineName { get; set; }
    }
}
