﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Models
{
    public class AirlineModel
    {
        public string AirlineName { get; set; }
        public string AirlineNumber { get; set; }
       
        //public int CreatedById { get; set; }
        //public DateTime CreatedDate { get; set; }
    }
}
