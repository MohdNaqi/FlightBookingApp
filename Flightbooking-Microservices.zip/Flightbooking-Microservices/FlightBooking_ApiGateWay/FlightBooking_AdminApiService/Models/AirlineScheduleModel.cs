﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Models
{
    public class AirlineScheduleModel
    {
     
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public DateTime? StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public string ScheduledDayId { get; set; }
        public string InstrumentUsed { get; set; }
        public string NonBusinessClassSeat { get; set; }
        public string BusinessClassSeats { get; set; }
        public decimal? TicketCost { get; set; }
        public string MealId { get; set; }
        public string Couper { get; set; }
        public int? DiscountValue { get; set; }
        public string AirlineName { get; set; }
        public string AirlineNumber { get; set; }

    }
}
