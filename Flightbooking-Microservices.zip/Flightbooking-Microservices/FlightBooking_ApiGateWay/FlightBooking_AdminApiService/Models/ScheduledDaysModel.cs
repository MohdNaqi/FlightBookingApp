﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Models
{
    public class ScheduledDaysModel
    {
        public bool Daily { get; set; }
        public bool WeekDays { get; set; }

        public bool WeekEnd { get; set; }
        public bool specificdays {get;set;}
        public SpecificDaysModel specificDaysModel { get; set; }
    }
}
