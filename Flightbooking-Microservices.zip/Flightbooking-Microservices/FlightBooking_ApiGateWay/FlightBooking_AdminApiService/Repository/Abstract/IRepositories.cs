﻿using FlightBooking_AdminApiService.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Repository.Abstract
{
    public interface IRepositories : IDisposable
    {
        FlightBookingContext flightBookingContext { get; }
    }
}
