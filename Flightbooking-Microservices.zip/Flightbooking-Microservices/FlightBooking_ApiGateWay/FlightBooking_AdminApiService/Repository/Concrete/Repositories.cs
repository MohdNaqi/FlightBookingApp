﻿using FlightBooking_AdminApiService.Entity;

using FlightBooking_AdminApiService.Repository.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Repository.Concrete
{
    public class Repositories : IRepositories
    {
        public Repositories()
        {
            this.flightBookingContext = new FlightBookingContext();
        }
        public FlightBookingContext flightBookingContext   { get; private set; }
        public void Dispose()
        {
            GC.SuppressFinalize("");
        }
    }
}
