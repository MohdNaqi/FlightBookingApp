﻿using FlightBooking_AdminApiService.Repository.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Repository.Concrete
{
    public class RepositoryCollection : IRepositoryCollection
    {
        public IAccountRepository AccountRepository
        {
            get { return this.AccountRepository = new AccountRepository(); }
            private set { }
        }

        public IManageFlightRepository ManageFlightRepository
        {
            get { return this.ManageFlightRepository = new ManageFlightRepository(); }
            private set { }
        }

        public IDiscountRepository ManageDiscount
        {
            get { return this.ManageDiscount = new DiscountRepository(); }
            private set { }
        }


        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~RepositoryCollection()
        {
            Dispose(false);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // free managed resources
                if (AccountRepository != null)
                {
                    AccountRepository.Dispose();
                    AccountRepository = null;
                }

            }
        }
    }
}
