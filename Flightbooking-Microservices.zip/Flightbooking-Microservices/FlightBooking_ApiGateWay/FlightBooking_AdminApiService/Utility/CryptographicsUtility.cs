﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Utility
{
   
    public static class CryptographicsUtility
    {
        public static string GetStringSha256Hash(this string text)
        {
            if (String.IsNullOrEmpty(text))
                return String.Empty;

            using (var sha = new System.Security.Cryptography.SHA256Managed())
            {
                byte[] textData = Encoding.UTF8.GetBytes(text);
                byte[] hash = sha.ComputeHash(textData);
                return BitConverter.ToString(hash).Replace("-", String.Empty);
            }

        }

        public static string RemoveWhiteSpace(this string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                value = Regex.Replace(value, @"\s+", " ");

                if (value.Contains("\t"))
                {
                    value = value.Replace("\t", " ");
                }
                value = value.Trim();
            }

            return value;
        }
    }
}
