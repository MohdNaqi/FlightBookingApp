﻿using System;
using System.Collections.Generic;

namespace FlightBooking_UserApiService.Entity
{
    public partial class Booking
    {
        public int BookingId { get; set; }
        public int? BookingUserId { get; set; }
        public int? BookingFlightId { get; set; }
        public string BookingDate { get; set; }
        public string BookingTotalFare { get; set; }
        public string BookingJourneyDate { get; set; }
        public string BookingSeatType { get; set; }
        public int? BookingSeatNumber { get; set; }
        public string BookingStatus { get; set; }
        public long? BookingPnr { get; set; }
        public bool? IsActive { get; set; }
        public int? Createdby { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string DiscountCoupenName { get; set; }
        public decimal? WithDiscountPrice { get; set; }
    }
}
