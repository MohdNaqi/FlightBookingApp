﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FlightBooking_UserApiService.Entity
{
    public partial class FlightBookingContext : DbContext
    {
        public FlightBookingContext()
        {
        }

        public FlightBookingContext(DbContextOptions<FlightBookingContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Address> Address { get; set; }
        public virtual DbSet<Airline> Airline { get; set; }
        public virtual DbSet<Booking> Booking { get; set; }
        public virtual DbSet<Discount> Discount { get; set; }
        public virtual DbSet<FlightSchedule> FlightSchedule { get; set; }
        public virtual DbSet<Meal> Meal { get; set; }
        public virtual DbSet<Passenger> Passenger { get; set; }
        public virtual DbSet<UserAccount> UserAccount { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=LAPTOP-VINDHGPQ;Database=FlightBooking;User Id=sa;Password=123456;MultipleActiveResultSets=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Address>(entity =>
            {
                entity.Property(e => e.Address1)
                    .HasColumnName("Address")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.Address11)
                    .HasColumnName("Address1")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.CityName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.CountryName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.StateName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.ZipCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Airline>(entity =>
            {
                entity.Property(e => e.AirlineId).HasColumnName("AirlineID");

                entity.Property(e => e.AirlineName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AirlineNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<Booking>(entity =>
            {
                entity.Property(e => e.BookingDate)
                    .HasColumnName("Booking_Date")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BookingFlightId).HasColumnName("Booking_Flight_Id");

                entity.Property(e => e.BookingJourneyDate)
                    .HasColumnName("Booking_Journey_Date")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BookingPnr).HasColumnName("Booking_PNR");

                entity.Property(e => e.BookingSeatNumber).HasColumnName("Booking_Seat_Number");

                entity.Property(e => e.BookingSeatType)
                    .HasColumnName("Booking_Seat_type")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BookingStatus)
                    .HasColumnName("Booking_Status")
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.BookingTotalFare)
                    .HasColumnName("Booking_total_Fare")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BookingUserId).HasColumnName("Booking_User_Id");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DiscountCoupenName).HasMaxLength(30);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.WithDiscountPrice).HasColumnType("decimal(18, 0)");
            });

            modelBuilder.Entity<Discount>(entity =>
            {
                entity.Property(e => e.CouponCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<FlightSchedule>(entity =>
            {
                entity.HasKey(e => e.FlightScheduledId);

                entity.Property(e => e.FlightScheduledId).HasColumnName("FlightScheduledID");

                entity.Property(e => e.BusinessClassSeats).HasMaxLength(60);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.EndDateTime).HasColumnType("datetime");

                entity.Property(e => e.FromPlace).HasMaxLength(250);

                entity.Property(e => e.InstrumentUsed).HasMaxLength(120);

                entity.Property(e => e.MealId).HasMaxLength(60);

                entity.Property(e => e.ModiifiedDate).HasColumnType("datetime");

                entity.Property(e => e.NonBusinessClassSeat).HasMaxLength(60);

                entity.Property(e => e.ScheduledDayId).HasMaxLength(120);

                entity.Property(e => e.StartDateTime).HasColumnType("datetime");

                entity.Property(e => e.ToPlace).HasMaxLength(250);
            });

            modelBuilder.Entity<Meal>(entity =>
            {
                entity.Property(e => e.MealName).HasMaxLength(50);
            });

            modelBuilder.Entity<Passenger>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.PassengerBookingId).HasColumnName("Passenger_Booking_Id");

                entity.Property(e => e.PassengerEmail)
                    .HasColumnName("Passenger_Email")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerFirstName)
                    .HasColumnName("Passenger_FirstName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerGender)
                    .HasColumnName("Passenger_Gender")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerLastName)
                    .HasColumnName("Passenger_LastName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerType)
                    .HasColumnName("Passenger_type")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserAccount>(entity =>
            {
                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Email).HasMaxLength(150);

                entity.Property(e => e.FirstName).HasMaxLength(70);

                entity.Property(e => e.LastName).HasMaxLength(70);

                entity.Property(e => e.PhoneNumber).HasMaxLength(20);

                entity.Property(e => e.UpdatedBy).HasMaxLength(50);

                entity.Property(e => e.UpdatedOn).HasColumnType("datetime");

                entity.Property(e => e.UserName).HasMaxLength(100);
            });
        }
    }
}
