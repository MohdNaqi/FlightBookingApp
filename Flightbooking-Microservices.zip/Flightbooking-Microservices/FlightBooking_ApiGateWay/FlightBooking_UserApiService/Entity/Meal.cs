﻿using System;
using System.Collections.Generic;

namespace FlightBooking_UserApiService.Entity
{
    public partial class Meal
    {
        public int MealId { get; set; }
        public string MealName { get; set; }
    }
}
