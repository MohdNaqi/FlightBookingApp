﻿using System;
using System.Collections.Generic;

namespace FlightBooking_UserApiService.Entity
{
    public partial class ScheduledDays
    {
        public int Id { get; set; }
        public string ScheduledDay { get; set; }
    }
}
