﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Models
{
    public class FlightBookingModel
    {
        public int FlightId { get; set; }
        //public int UserId { get; set; }
        //public int Booking_User_Id { get; set; }
        //public int Booking_Flight_Id { get; set; }
        //public string Booking_Date { get; set; }
        public string Booking_total_Fare { get; set; }
        public string Booking_Journey_Date { get; set; }
        public string Booking_Seat_type { get; set; }
        //public string Booking_Status { get; set; }
        //public long Booking_PNR { get; set; }
        public int BookingSeatNumber { get; set; }

        //public int Passenger_Booking_Id { get; set; }
        public string Passenger_type { get; set; }
        public string Passenger_FirstName { get; set; }
        public string Passenger_LastName { get; set; }
        public string Passenger_Email { get; set; }
        public string Passenger_Gender { get; set; }
        public string mealName { get; set; }
        public string DiscountCoupenName { get; set; }
        public decimal WithDiscountPrice { get; set; }

        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
