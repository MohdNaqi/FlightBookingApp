﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Models
{
    public class GetFlightModel
    {
        public int AirlineID { get; set; }
        public string AirlineNumber { get; set; }
        public string AirlineName { get; set; }
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public string StartDateTime { get; set; }
        public string EndDateTime { get; set; }
        public string TicketCost { get; set; }
        public string BusinessClassSeats { get; set; }
        public string NonBusinessClassSeat { get; set; }
    }
}
