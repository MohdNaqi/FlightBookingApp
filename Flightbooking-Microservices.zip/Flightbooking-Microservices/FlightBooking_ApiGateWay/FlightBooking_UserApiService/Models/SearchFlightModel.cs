﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Models
{
    public class SearchFlightModel
    {
        public DateTime Flight { get; set; }
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
    }
}
