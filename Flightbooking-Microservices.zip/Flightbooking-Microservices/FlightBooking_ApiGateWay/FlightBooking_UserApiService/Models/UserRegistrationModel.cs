﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Models
{
    public class UserRegistrationModel
    {
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int UserType { get; set; }
        public string PhoneNumber { get; set; }
        public string password { get; set; }

        public string Address1 { get; set; }
        public string Address11 { get; set; }
        public string CityName { get; set; }
        public string StateName { get; set; }
        public string CountryName { get; set; }
        public string ZipCode { get; set; }
        //public string CreatedById { get; set; }
        //public UserAddressModel userAddressModel { get; set; }
    }
}
