﻿
using FlightBooking_UserApiService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Repository.Abstract
{
    public interface IAccountRepository : IDisposable
    {
        Task<LoginDetailsModel> UserLogin(LoginModel objLoginModel);
        Task<ResponseMessageModel> AddUserRegistration(UserRegistrationModel registrationModel);
    }
}
