﻿using FlightBooking_UserApiService.Models;
using FlightBooking_UserApiService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Repository.Abstract
{
    public interface IBookingRepository :IDisposable
    {
        Task<GetFlightModel> SearchFlight(SearchFlightModel searchFlight);
        Task<ResponseMessageModel> FlightBooking(FlightBookingModel flightBooking);

        Task<ResponseMessageModel> flightBookingCancel(int bookingId);

        Task<List<BookingDetailsViewModel>> BookTicketDetails(long PNR_No);

        Task<List<BookingDetailsViewModel>> BookingHistoryDetailsByEmailId(string email);

        Task<List<GetAirLineModel>> GetActiveAirLine();

        Task<List<GetAirLineModel>> GetActiveAirlineSchedule();
        Task<List<BookingDetailsViewModel>> GetBookTicket();
        Task<DiscountModel> GetPriceandDiscountCoupen(int flightid);
    }
}
